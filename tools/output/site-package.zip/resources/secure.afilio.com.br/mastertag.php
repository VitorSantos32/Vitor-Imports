
                              // dynaton PART
          window.dynatonOptions = {
    app_id: 'zattini' 
};
var content=document.createElement('script');
content.async = true;
content.src = window.location.protocol+'//cdn.dynaton.com.br/tr_zattini.js';
document.getElementsByTagName('body')[0].appendChild(content);
                              // END dynaton PART
          
                              // provisorio PART
          //17456 
(function(){
var a = document.createElement('script');
a.type = 'text/javascript';
a.async = true;
a.src = 'https://adtargett.com/cdn/zattini_adtarget_v4b.js';
var s = document.getElementsByTagName('script')[0];
s.parentNode.insertBefore(a, s);
})();
                              // END provisorio PART
          